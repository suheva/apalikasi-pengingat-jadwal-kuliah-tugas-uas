package com.example.latihan4_navigasi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
