# TODO: Change Theme to Pink and White

- [x] Update lib/main.dart: Change primary color to pink (0xFFE91E63), app bar to white background with pink text, buttons to pink, borders to pink.
- [x] Update lib/screens/profil_page.dart: Change gradient, avatar, and icons to pink and white.
- [x] Add photo feature to profile page: Allow students to add their photo using image picker.
