import 'package:flutter/material.dart';
import '../models/data_models.dart';
import '../models/data_manager.dart';

class LaporanTugasPage extends StatefulWidget {
  const LaporanTugasPage({super.key});

  @override
  _LaporanTugasPageState createState() => _LaporanTugasPageState();
}

class _LaporanTugasPageState extends State<LaporanTugasPage> {
  List<Tugas> _tugas = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final data = await DataManager.loadTugas();
    setState(() {
      _tugas = data;
    });
  }

  Future<void> _saveData() async {
    await DataManager.saveTugas(_tugas);
  }

  void _toggleSelesai(int index) {
    setState(() {
      _tugas[index].selesai = !_tugas[index].selesai;
    });
    _saveData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Laporan Tugas'), centerTitle: true),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.white, Color(0xFFFCE4EC)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Daftar Tugas:',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: 20),
              Expanded(
                child: ListView.builder(
                  itemCount: _tugas.length,
                  itemBuilder: (context, index) {
                    return Card(
                      color: _tugas[index].selesai
                          ? Colors.green[800]
                          : Color(0xFFE91E63),
                      child: ListTile(
                        title: Text(
                          _tugas[index].deskripsi,
                          style: TextStyle(color: Colors.white),
                        ),
                        subtitle: _tugas[index].mataKuliah != null
                            ? Text(
                                'MK: ${_tugas[index].mataKuliah}',
                                style: TextStyle(color: Colors.white70),
                              )
                            : null,
                        leading: Checkbox(
                          value: _tugas[index].selesai,
                          onChanged: (value) => _toggleSelesai(index),
                          activeColor: Colors.white,
                          checkColor: Colors.black,
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
