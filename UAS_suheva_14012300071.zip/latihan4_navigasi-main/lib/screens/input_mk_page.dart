import 'package:flutter/material.dart';
import '../models/data_models.dart';
import '../models/data_manager.dart';

class InputMKPage extends StatefulWidget {
  const InputMKPage({super.key});

  @override
  _InputMKPageState createState() => _InputMKPageState();
}

class _InputMKPageState extends State<InputMKPage> {
  final TextEditingController _mkController = TextEditingController();
  final TextEditingController _sksController = TextEditingController();
  final TextEditingController _kelasController = TextEditingController();
  final TextEditingController _dosenController = TextEditingController();
  List<MataKuliah> _mataKuliah = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final data = await DataManager.loadMataKuliah();
    setState(() {
      _mataKuliah = data;
    });
  }

  Future<void> _saveData() async {
    await DataManager.saveMataKuliah(_mataKuliah);
  }

  void _addMK() {
    if (_mkController.text.isNotEmpty) {
      setState(() {
        _mataKuliah.add(MataKuliah(
          nama: _mkController.text,
          sks: int.tryParse(_sksController.text),
          kelas: _kelasController.text.isNotEmpty ? _kelasController.text : null,
          namaDosen: _dosenController.text.isNotEmpty ? _dosenController.text : null,
        ));
        _mkController.clear();
        _sksController.clear();
        _kelasController.clear();
        _dosenController.clear();
      });
      _saveData();
    }
  }



  void _deleteMK(int index) {
    setState(() {
      _mataKuliah.removeAt(index);
    });
    _saveData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Input Mata Kuliah'), centerTitle: true),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.white, Color(0xFFE3F2FD)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
                  TextField(
                    controller: _mkController,
                    decoration: InputDecoration(
                      labelText: 'Nama Mata Kuliah',
                      prefixIcon: Icon(Icons.book, color: Color(0xFFE91E63)),
                    ),
                    style: TextStyle(color: Colors.black),
                  ),
                  SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _sksController,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            labelText: 'SKS',
                            prefixIcon: Icon(Icons.confirmation_number, color: Color(0xFFE91E63)),
                          ),
                        ),
                      ),
                      SizedBox(width: 8),
                      Expanded(
                        child: TextField(
                          controller: _kelasController,
                          decoration: InputDecoration(
                            labelText: 'Kelas',
                            prefixIcon: Icon(Icons.class_, color: Color(0xFFE91E63)),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 8),
                  TextField(
                    controller: _dosenController,
                    decoration: InputDecoration(
                      labelText: 'Nama Dosen',
                      prefixIcon: Icon(Icons.person, color: Color(0xFFE91E63)),
                    ),
                  ),
              SizedBox(height: 20),
              ElevatedButton(onPressed: _addMK, child: Text('Tambah MK')),
              SizedBox(height: 20),
              Expanded(
                child: ListView.builder(
                  itemCount: _mataKuliah.length,
                  itemBuilder: (context, index) {
                    return Card(
                      color: Color(0xFFE91E63),
                      child: ListTile(
                        title: Text(
                          _mataKuliah[index].nama,
                          style: TextStyle(color: Colors.white),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (_mataKuliah[index].sks != null)
                              Text('SKS: ${_mataKuliah[index].sks}', style: TextStyle(color: Colors.white70)),
                            if (_mataKuliah[index].kelas != null && _mataKuliah[index].kelas!.isNotEmpty)
                              Text('Kelas: ${_mataKuliah[index].kelas}', style: TextStyle(color: Colors.white70)),
                            if (_mataKuliah[index].namaDosen != null && _mataKuliah[index].namaDosen!.isNotEmpty)
                              Text('Dosen: ${_mataKuliah[index].namaDosen}', style: TextStyle(color: Colors.white70)),
                          ],
                        ),
                        trailing: IconButton(
                          icon: Icon(Icons.delete, color: Colors.white),
                          onPressed: () => _deleteMK(index),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
