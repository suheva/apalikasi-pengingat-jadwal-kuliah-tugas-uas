import 'package:flutter/material.dart';
import 'input_mk_page.dart';
import 'atur_jadwal_page.dart';
import 'pengingat_tugas_page.dart';
import 'laporan_tugas_page.dart';
import 'profil_page.dart';
import 'login_page.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/data_models.dart';
import '../models/data_manager.dart';
import '../models/database_helper.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  List<Tugas> _tugas = [];
  Profil? _profil;

  @override
  void initState() {
    super.initState();
    _loadTugas();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _loadTugas(); // Refresh data setiap kali kembali ke page
  }

  Future<void> _loadTugas() async {
    final tugasData = await DataManager.loadTugas();
    final profilData = await DataManager.loadProfil();
    setState(() {
      _tugas = tugasData;
      _profil = profilData;
    });
  }

  int get _totalTugas => _tugas.length;
  int get _selesai => _tugas.where((t) => t.selesai).length;
  int get _belumSelesai => _totalTugas - _selesai;
  double get _progress => _totalTugas == 0 ? 0 : (_selesai / _totalTugas) * 100;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Dashboard'), centerTitle: true),
      drawer: Drawer(
        child: Container(
          color: Colors.white,
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              DrawerHeader(
                decoration: BoxDecoration(
                  color: Color(0xFFE91E63),
                  gradient: LinearGradient(
                    colors: [Color(0xFFE91E63), Color(0xFFFCE4EC)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Text(
                  'Menu Navigasi',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              ListTile(
                leading: Icon(Icons.book, color: Color(0xFFE91E63)),
                title: Text('Input MK', style: TextStyle(color: Colors.black)),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => InputMKPage()),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.schedule, color: Color(0xFFE91E63)),
                title: Text(
                  'Atur Jadwal',
                  style: TextStyle(color: Colors.black),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => AturJadwalPage()),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.notifications, color: Color(0xFFE91E63)),
                title: Text(
                  'Pengingat Tugas',
                  style: TextStyle(color: Colors.black),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PengingatTugasPage(),
                    ),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.report, color: Color(0xFFE91E63)),
                title: Text(
                  'Laporan Tugas',
                  style: TextStyle(color: Colors.black),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => LaporanTugasPage()),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.person, color: Color(0xFFE91E63)),
                title: Text(
                  'Profil Mahasiswa',
                  style: TextStyle(color: Colors.black),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ProfilPage()),
                  );
                },
              ),
              Divider(),
              ListTile(
                leading: Icon(Icons.logout, color: Color(0xFFE91E63)),
                title: Text(
                  'Logout',
                  style: TextStyle(color: Colors.black),
                ),
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: Text('Konfirmasi Logout'),
                        content: Text('Apakah Anda yakin ingin logout?'),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop(); // Close the dialog
                            },
                            child: Text('Batal'),
                          ),
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop(); // Close the dialog
                              Navigator.pushAndRemoveUntil(
                                context,
                                MaterialPageRoute(builder: (context) => LoginPage()),
                                (Route<dynamic> route) => false,
                              );
                            },
                            child: Text('Ya'),
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
            ],
          ),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.white, Color(0xFFE3F2FD)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: LayoutBuilder(
          builder: (context, constraints) {
            bool isMobile = constraints.maxWidth < 600;
            double chartSize = isMobile ? 150 : 200;
            double padding = isMobile ? 16.0 : 32.0;
            return Padding(
              padding: EdgeInsets.all(padding),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Sambutan
                    Center(
                      child: Column(
                        children: [
                          Icon(
                            Icons.school,
                            size: isMobile ? 80 : 100,
                            color: Color(0xFFE91E63),
                          ),
                          SizedBox(height: 20),
                          Text(
                            'Selamat Datang ${_profil?.nama ?? 'Pengguna'}!',
                            style: TextStyle(
                              fontSize: isMobile ? 20 : 24,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          SizedBox(height: 20),
                          Text(
                            'Kelola jadwal kuliah dan tugas Anda dengan mudah.',
                            style: TextStyle(
                              fontSize: isMobile ? 14 : 16,
                              color: Colors.black87,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 40),
                    // Ringkasan Tugas
                    Center(
                      child: Text(
                        'Ringkasan Tugas',
                        style: TextStyle(
                          fontSize: isMobile ? 18 : 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    // Doughnut Chart
                    Container(
                      height: chartSize,
                      child: PieChart(
                        PieChartData(
                          sections: _totalTugas == 0
                              ? [
                                  PieChartSectionData(
                                    value: 1,
                                    title: 'Tidak ada\ntugas',
                                    color: Colors.grey,
                                    radius: chartSize / 3,
                                    titleStyle: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                ]
                              : [
                                  PieChartSectionData(
                                    value: _selesai.toDouble(),
                                    title: 'Selesai\n$_selesai',
                                    color: Colors.green,
                                    radius: chartSize / 3,
                                    titleStyle: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                  PieChartSectionData(
                                    value: _belumSelesai.toDouble(),
                                    title: 'Belum\n$_belumSelesai',
                                    color: Color(0xFFE91E63),
                                    radius: chartSize / 3,
                                    titleStyle: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                ],
                          sectionsSpace: 2,
                          centerSpaceRadius: chartSize / 6,
                          centerSpaceColor: Colors.white,
                          pieTouchData: PieTouchData(
                            touchCallback: (FlTouchEvent event, pieTouchResponse) {
                              if (event is FlTapUpEvent &&
                                  pieTouchResponse != null &&
                                  pieTouchResponse.touchedSection != null) {
                                final touchedIndex = pieTouchResponse
                                    .touchedSection!
                                    .touchedSectionIndex;
                                String message;
                                if (_totalTugas == 0) {
                                  message = 'Tidak ada tugas';
                                } else if (touchedIndex == 0) {
                                  message =
                                      'Tugas selesai: $_selesai dari $_totalTugas';
                                } else {
                                  message =
                                      'Tugas belum selesai: $_belumSelesai dari $_totalTugas';
                                }
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text(message)),
                                );
                              }
                            },
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    // Center Progress Text
                    Center(
                      child: Text(
                        _totalTugas == 0
                            ? 'Belum ada tugas'
                            : '${_progress.toStringAsFixed(1)}% Selesai',
                        style: TextStyle(
                          fontSize: isMobile ? 16 : 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
      floatingActionButton: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton(
            onPressed: _loadTugas,
            child: Icon(Icons.refresh),
            tooltip: 'Refresh Data',
          ),
          SizedBox(height: 10),
          FloatingActionButton(
            onPressed: () async {
              await DatabaseHelper().testMK();
            },
            child: Icon(Icons.bug_report),
            tooltip: 'Test MK',
          ),
        ],
      ),
    );
  }
}
