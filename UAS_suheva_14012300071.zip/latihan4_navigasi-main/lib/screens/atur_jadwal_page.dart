import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/data_models.dart';
import '../models/data_manager.dart';
import '../models/database_helper.dart';

class AturJadwalPage extends StatefulWidget {
  const AturJadwalPage({super.key});

  @override
  _AturJadwalPageState createState() => _AturJadwalPageState();
}

class _AturJadwalPageState extends State<AturJadwalPage> {
  List<Jadwal> _jadwal = [];
  int? _selectedMKId;
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _loadData(); // Refresh data setiap kali kembali ke page
  }

  Future<void> _loadData() async {
    final jadwalData = await DataManager.loadJadwal();
    setState(() {
      _jadwal = jadwalData;
    });
  }

  Future<void> _saveData() async {
    await DataManager.saveJadwal(_jadwal);
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime ?? TimeOfDay.now(),
    );
    if (picked != null && picked != _selectedTime) {
      setState(() {
        _selectedTime = picked;
      });
    }
  }

  void _addJadwal() async {
    if (_selectedMKId != null && _selectedDate != null && _selectedTime != null) {
      final mkList = await DatabaseHelper().getMataKuliah();
      final selectedMK = mkList.firstWhere((mk) => mk['id'] == _selectedMKId)['nama'];
      final jadwal = Jadwal(
        mataKuliah: selectedMK,
        tanggal: DateFormat('yyyy-MM-dd').format(_selectedDate!),
        waktu: _selectedTime!.format(context),
      );
      setState(() {
        _jadwal.add(jadwal);
        _resetForm();
      });
      _saveData();
    } else {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Isi semua field')));
    }
  }

  void _resetForm() {
    _selectedMKId = null;
    _selectedDate = null;
    _selectedTime = null;
  }

  void _editJadwal(int index) async {
    final jadwal = _jadwal[index];
    final mkList = await DatabaseHelper().getMataKuliah();
    _selectedMKId = mkList.firstWhere((mk) => mk['nama'] == jadwal.mataKuliah)['id'];
    _selectedDate = DateFormat('yyyy-MM-dd').parse(jadwal.tanggal);
    _selectedTime = TimeOfDay.fromDateTime(
      DateFormat('HH:mm').parse(jadwal.waktu),
    );

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setStateDialog) => AlertDialog(
          title: Text('Edit Jadwal'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                FutureBuilder<List<Map<String, dynamic>>>(
                  future: DatabaseHelper().getMataKuliah(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return CircularProgressIndicator();
                    } else if (snapshot.hasError) {
                      return Text('Error: ${snapshot.error}');
                    } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                      return Text('Tidak ada data Mata Kuliah');
                    } else {
                      final mkList = snapshot.data!;
                      return DropdownButtonFormField<int>(
                        value: _selectedMKId,
                        decoration: InputDecoration(labelText: 'Mata Kuliah'),
                        items: mkList.map((mk) {
                          return DropdownMenuItem<int>(
                            value: mk['id'],
                            child: Text(mk['nama']),
                          );
                        }).toList(),
                        onChanged: (value) {
                          setStateDialog(() {
                            _selectedMKId = value;
                          });
                        },
                      );
                    }
                  },
                ),
                SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () async {
                    await _selectDate(context);
                    setStateDialog(() {});
                  },
                  child: Text(
                    _selectedDate == null
                        ? 'Pilih Tanggal'
                        : DateFormat('yyyy-MM-dd').format(_selectedDate!),
                  ),
                ),
                SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () async {
                    await _selectTime(context);
                    setStateDialog(() {});
                  },
                  child: Text(
                    _selectedTime == null
                        ? 'Pilih Waktu'
                        : _selectedTime!.format(context),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _resetForm();
              },
              child: Text('Batal'),
            ),
            TextButton(
              onPressed: () async {
                if (_selectedMKId != null &&
                    _selectedDate != null &&
                    _selectedTime != null) {
                  final mkList = await DatabaseHelper().getMataKuliah();
                  final selectedMK = mkList.firstWhere((mk) => mk['id'] == _selectedMKId)['nama'];
                  setState(() {
                    _jadwal[index] = Jadwal(
                      mataKuliah: selectedMK,
                      tanggal: DateFormat('yyyy-MM-dd').format(_selectedDate!),
                      waktu: _selectedTime!.format(context),
                    );
                  });
                  _saveData();
                  Navigator.of(context).pop();
                  _resetForm();
                }
              },
              child: Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }

  void _deleteJadwal(int index) {
    setState(() {
      _jadwal.removeAt(index);
    });
    _saveData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Atur Jadwal'), centerTitle: true),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.white, Color(0xFFFCE4EC)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              FutureBuilder<List<Map<String, dynamic>>>(
                future: DatabaseHelper().getMataKuliah(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return CircularProgressIndicator();
                  } else if (snapshot.hasError) {
                    return Text('Error: ${snapshot.error}');
                  } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    return Text('Tidak ada data Mata Kuliah');
                  } else {
                    final mkList = snapshot.data!;
                    return DropdownButtonFormField<int>(
                      value: _selectedMKId,
                      decoration: InputDecoration(
                        labelText: 'Mata Kuliah',
                        prefixIcon: Icon(Icons.book, color: Color(0xFFE91E63)),
                        labelStyle: TextStyle(color: Colors.black),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Color(0xFFE91E63)),
                        ),
                      ),
                      dropdownColor: Color(0xFFE91E63),
                      style: TextStyle(color: Colors.black),
                      items: mkList.map((mk) {
                        return DropdownMenuItem<int>(
                          value: mk['id'],
                          child: Text(mk['nama'], style: TextStyle(color: Colors.black)),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() {
                          _selectedMKId = value;
                        });
                      },
                    );
                  }
                },
              ),
              SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => _selectDate(context),
                      child: Text(
                        _selectedDate == null
                            ? 'Pilih Tanggal'
                            : DateFormat('yyyy-MM-dd').format(_selectedDate!),
                      ),
                    ),
                  ),
                  SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => _selectTime(context),
                      child: Text(
                        _selectedTime == null
                            ? 'Pilih Waktu'
                            : _selectedTime!.format(context),
                      ),
                    ),
                  ),
                  SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _addJadwal,
                      child: Text('Tambah Jadwal'),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20),
              Expanded(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    columns: [
                      DataColumn(
                        label: Text(
                          'Mata Kuliah',
                          style: TextStyle(color: Colors.black),
                        ),
                      ),
                      DataColumn(
                        label: Text(
                          'SKS',
                          style: TextStyle(color: Colors.black),
                        ),
                      ),
                      DataColumn(
                        label: Text(
                          'Kelas',
                          style: TextStyle(color: Colors.black),
                        ),
                      ),
                      DataColumn(
                        label: Text(
                          'Dosen',
                          style: TextStyle(color: Colors.black),
                        ),
                      ),
                      DataColumn(
                        label: Text(
                          'Tanggal',
                          style: TextStyle(color: Colors.black),
                        ),
                      ),
                      DataColumn(
                        label: Text(
                          'Waktu',
                          style: TextStyle(color: Colors.black),
                        ),
                      ),
                      DataColumn(
                        label: Text(
                          'Aksi',
                          style: TextStyle(color: Colors.black),
                        ),
                      ),
                    ],
                    rows: _jadwal.map((jadwal) {
                      return DataRow(
                        cells: [
                          DataCell(
                            Text(
                              jadwal.mataKuliah,
                              style: TextStyle(color: Colors.black),
                            ),
                          ),
                          DataCell(
                            Text(
                              '',
                              style: TextStyle(color: Colors.black),
                            ),
                          ),
                          DataCell(
                            Text(
                              '',
                              style: TextStyle(color: Colors.black),
                            ),
                          ),
                          DataCell(
                            Text(
                              '',
                              style: TextStyle(color: Colors.black),
                            ),
                          ),
                          DataCell(
                            Text(
                              jadwal.tanggal,
                              style: TextStyle(color: Colors.black),
                            ),
                          ),
                          DataCell(
                            Text(
                              jadwal.waktu,
                              style: TextStyle(color: Colors.black),
                            ),
                          ),
                          DataCell(
                            Row(
                              children: [
                                IconButton(
                                  icon: Icon(
                                    Icons.edit,
                                    color: Color(0xFFE91E63),
                                  ),
                                  onPressed: () =>
                                      _editJadwal(_jadwal.indexOf(jadwal)),
                                ),
                                IconButton(
                                  icon: Icon(
                                    Icons.delete,
                                    color: Color(0xFFE91E63),
                                  ),
                                  onPressed: () =>
                                      _deleteJadwal(_jadwal.indexOf(jadwal)),
                                ),
                              ],
                            ),
                          ),
                        ],
                      );
                    }).toList(),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
