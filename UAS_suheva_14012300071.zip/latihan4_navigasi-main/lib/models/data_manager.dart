import 'database_helper.dart';
import 'data_models.dart';

class DataManager {
  static Future<List<MataKuliah>> loadMataKuliah() async {
    final maps = await DatabaseHelper().getMataKuliah();
    final list = maps.cast<Map<String, dynamic>>();
    return list.map((map) => MataKuliah.fromJson(map)).toList();
  }

  static Future<void> saveMataKuliah(List<MataKuliah> mataKuliah) async {
    final db = DatabaseHelper();
    // Clear existing
    final existing = await db.getMataKuliah();
    for (var item in existing) {
      final id = item['id'];
      if (id != null) await db.deleteMataKuliah(id as int);
    }
    // Insert new
    for (var item in mataKuliah) {
      await db.insertMataKuliah(item.toJson());
    }
  }

  static Future<List<Jadwal>> loadJadwal() async {
    final rows = await DatabaseHelper().getJadwal();
    final list = rows.cast<Map<String, dynamic>>();
    return list.map((r) => Jadwal.fromJson(r)).toList();
  }

  static Future<void> saveJadwal(List<Jadwal> jadwal) async {
    final db = DatabaseHelper();
    // Clear existing
    final existing = await db.getJadwal();
    for (var item in existing) {
      final id = item['id'];
      if (id != null) await db.deleteJadwal(id as int);
    }
    // Insert new
    for (var item in jadwal) {
      await db.insertJadwal(item.toJson());
    }
  }

  static Future<List<Tugas>> loadTugas() async {
    final rows = await DatabaseHelper().getTugas();
    final list = rows.cast<Map<String, dynamic>>();
    return list.map((r) => Tugas.fromJson(r)).toList();
  }

  static Future<void> saveTugas(List<Tugas> tugas) async {
    final db = DatabaseHelper();
    // Clear existing
    final existing = await db.getTugas();
    for (var item in existing) {
      final id = item['id'];
      if (id != null) await db.deleteTugas(id as int);
    }
    // Insert new
    for (var item in tugas) {
      await db.insertTugas(item.toJson());
    }
  }

  static Future<Profil?> loadProfil() async {
    final map = await DatabaseHelper().getProfil();
    if (map == null) return null;
    return Profil.fromJson(map);
  }

  static Future<void> saveProfil(Profil profil) async {
    final db = DatabaseHelper();
    final existing = await db.getProfil();
    if (existing != null && existing['id'] != null) {
      await db.updateProfil(profil.toJson());
    } else {
      await db.insertProfil(profil.toJson());
    }
  }
}
