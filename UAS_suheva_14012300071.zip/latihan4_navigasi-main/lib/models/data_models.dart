import 'package:flutter/material.dart';

class MataKuliah {
  int? id;
  String nama;
  int? sks;
  String? kelas;
  String? namaDosen;

  MataKuliah({
    this.id,
    required this.nama,
    this.sks,
    this.kelas,
    this.namaDosen,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'nama': nama,
    'sks': sks,
    'kelas': kelas,
    'nama_dosen': namaDosen,
  };

  factory MataKuliah.fromJson(Map<String, dynamic> json) {
    return MataKuliah(
      id: json['id'],
      nama: json['nama'] ?? '',
      sks: json['sks'] != null ? (json['sks'] is int ? json['sks'] as int : int.tryParse(json['sks'].toString())) : null,
      kelas: json['kelas'] ?? json['kelas'],
      namaDosen: json['nama_dosen'] ?? json['nama_dosen'],
    );
  }
}

class Jadwal {
  int? id;
  String mataKuliah;
  String tanggal;
  String waktu;

  Jadwal({
    this.id,
    required this.mataKuliah,
    required this.tanggal,
    required this.waktu,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'mataKuliah': mataKuliah,
    'tanggal': tanggal,
    'waktu': waktu,
  };

  factory Jadwal.fromJson(Map<String, dynamic> json) {
    return Jadwal(
      id: json['id'],
      mataKuliah: json['mataKuliah'] ?? '',
      tanggal: json['tanggal'] ?? '',
      waktu: json['waktu'] ?? '',
    );
  }
}

class Tugas {
  int? id;
  String deskripsi;
  String? mataKuliah; // Tambahkan field ini
  DateTime? tanggal;
  TimeOfDay? waktu;
  bool selesai;

  Tugas({
    this.id,
    required this.deskripsi,
    this.mataKuliah,
    this.tanggal,
    this.waktu,
    this.selesai = false,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'deskripsi': deskripsi,
    'mataKuliah': mataKuliah,
    'tanggal': tanggal?.toIso8601String(),
    'waktu': waktu != null ? '${waktu!.hour}:${waktu!.minute}' : null,
    'selesai': selesai,
  };

  factory Tugas.fromJson(Map<String, dynamic> json) {
    TimeOfDay? waktu;
    if (json['waktu'] != null) {
      final parts = json['waktu'].split(':');
      waktu = TimeOfDay(hour: int.parse(parts[0]), minute: int.parse(parts[1]));
    }
    return Tugas(
      id: json['id'],
      deskripsi: json['deskripsi'],
      mataKuliah: json['mataKuliah'],
      tanggal: json['tanggal'] != null ? DateTime.parse(json['tanggal']) : null,
      waktu: waktu,
      selesai: json['selesai'] ?? false,
    );
  }
}

class Profil {
  int? id;
  String nama;
  String nim;
  String jurusan;
  String semester;

  Profil({
    this.id,
    required this.nama,
    required this.nim,
    required this.jurusan,
    required this.semester,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'nama': nama,
    'nim': nim,
    'jurusan': jurusan,
    'semester': semester,
  };

  factory Profil.fromJson(Map<String, dynamic> json) {
    return Profil(
      id: json['id'],
      nama: json['nama'] ?? 'John Doe',
      nim: json['nim'] ?? '123456789',
      jurusan: json['jurusan'] ?? 'Teknik Informatika',
      semester: json['semester'] ?? '4',
    );
  }
}
