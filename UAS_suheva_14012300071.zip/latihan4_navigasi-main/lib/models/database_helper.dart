import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._internal();
  static Database? _database;
  static SharedPreferences? _prefs;

  DatabaseHelper._internal();

  factory DatabaseHelper() {
    return instance;
  }

  Future<Database> get database async {
    if (kIsWeb) {
      // Web doesn't support sqflite, return dummy
      throw UnsupportedError('sqflite not supported on Web. Use getMataKuliah() etc methods instead.');
    }
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<SharedPreferences> _getPrefs() async {
    return _prefs ??= await SharedPreferences.getInstance();
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'latihan4_navigasi_v2.db');
    
    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
      onOpen: (db) async {
        print('Opened database at $path');
      },
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS mata_kuliah (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL,
        sks INTEGER,
        kelas TEXT,
        nama_dosen TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS jadwal (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        mata_kuliah_id INTEGER,
        tanggal TEXT NOT NULL,
        waktu TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS tugas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        deskripsi TEXT NOT NULL,
        mata_kuliah_id INTEGER,
        tanggal TEXT,
        waktu TEXT,
        selesai INTEGER NOT NULL DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS profil (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL,
        nim TEXT NOT NULL,
        jurusan TEXT NOT NULL,
        semester TEXT NOT NULL
      )
    ''');

    // DATA DEFAULT MATA KULIAH
    await db.insert('mata_kuliah', {
      'nama': 'Matematika Dasar',
      'sks': 3,
      'kelas': 'A',
      'nama_dosen': 'Dr. Ahmad'
    });
    await db.insert('mata_kuliah', {
      'nama': 'Fisika',
      'sks': 3,
      'kelas': 'B',
      'nama_dosen': 'Prof. Siti'
    });
    await db.insert('mata_kuliah', {
      'nama': 'Kimia',
      'sks': 3,
      'kelas': 'C',
      'nama_dosen': 'Dr. Budi'
    });
    await db.insert('mata_kuliah', {
      'nama': 'Bahasa Inggris',
      'sks': 2,
      'kelas': 'D',
      'nama_dosen': 'Ms. Lisa'
    });
  }

  // =========================
  // MATA KULIAH
  // =========================
  Future<int> insertMataKuliah(Map<String, dynamic> data) async {
    if (kIsWeb) {
      final prefs = await _getPrefs();
      final jsonStr = prefs.getString('mata_kuliah_list') ?? '[]';
      final List<dynamic> jsonList = jsonDecode(jsonStr);
      final list = List<Map<String, dynamic>>.from(jsonList.map((x) => Map<String, dynamic>.from(x as Map)));
      
      int maxId = list.isNotEmpty ? (list.map((m) => (m['id'] as int?) ?? 0).reduce((a, b) => a > b ? a : b)) : 0;
      data['id'] = maxId + 1;
      list.add(data);
      
      await prefs.setString('mata_kuliah_list', jsonEncode(list));
      return data['id'] as int;
    }
    final db = await database;
    return await db.insert('mata_kuliah', data);
  }

  Future<int> insertMataKuliahFlexible(dynamic data) async {
    final db = await database;
    if (data is String) {
      return await db.insert('mata_kuliah', {'nama': data});
    } else if (data is Map<String, dynamic>) {
      return await db.insert('mata_kuliah', data);
    } else {
      throw ArgumentError('Unsupported data type for insertMataKuliahFlexible');
    }
  }

  Future<List<Map<String, dynamic>>> getMataKuliah() async {
    if (kIsWeb) {
      // Web: use SharedPreferences
      final prefs = await _getPrefs();
      final jsonStr = prefs.getString('mata_kuliah_list') ?? '[]';
      final List<dynamic> jsonList = jsonDecode(jsonStr);
      return List<Map<String, dynamic>>.from(jsonList.map((x) => Map<String, dynamic>.from(x as Map)));
    }
    final db = await database;
    return await db.query('mata_kuliah');
  }

  Future<void> deleteMataKuliah(int id) async {
    if (kIsWeb) {
      final prefs = await _getPrefs();
      final jsonStr = prefs.getString('mata_kuliah_list') ?? '[]';
      final List<dynamic> jsonList = jsonDecode(jsonStr);
      final list = List<Map<String, dynamic>>.from(jsonList.map((x) => Map<String, dynamic>.from(x as Map)));
      list.removeWhere((item) => item['id'] == id);
      await prefs.setString('mata_kuliah_list', jsonEncode(list));
      return;
    }
    final db = await database;
    await db.delete('mata_kuliah', where: 'id = ?', whereArgs: [id]);
  }

  // =========================
  // JADWAL
  // =========================
  Future<int> insertJadwal(dynamic jadwal) async {
    if (kIsWeb) {
      final prefs = await _getPrefs();
      final jsonStr = prefs.getString('jadwal_list') ?? '[]';
      final List<dynamic> jsonList = jsonDecode(jsonStr);
      final list = List<Map<String, dynamic>>.from(jsonList.map((x) => Map<String, dynamic>.from(x as Map)));
      
      Map<String, dynamic> jadwalData = {};
      if (jadwal is Map<String, dynamic>) {
        jadwalData = jadwal;
      } else {
        jadwalData = {
          'mataKuliah': jadwal.mataKuliah ?? '',
          'tanggal': jadwal.tanggal ?? '',
          'waktu': jadwal.waktu ?? '',
        };
      }
      
      int maxId = list.isNotEmpty ? (list.map((m) => (m['id'] as int?) ?? 0).reduce((a, b) => a > b ? a : b)) : 0;
      jadwalData['id'] = maxId + 1;
      list.add(jadwalData);
      
      await prefs.setString('jadwal_list', jsonEncode(list));
      return jadwalData['id'] as int;
    }
    
    final db = await database;
    String mataKuliahName = '';
    String tanggal = '';
    String waktu = '';
    
    if (jadwal is Map<String, dynamic>) {
      mataKuliahName = jadwal['mataKuliah'] ?? '';
      tanggal = jadwal['tanggal'] ?? '';
      waktu = jadwal['waktu'] ?? '';
    } else {
      mataKuliahName = jadwal.mataKuliah ?? '';
      tanggal = jadwal.tanggal ?? '';
      waktu = jadwal.waktu ?? '';
    }

    int? mkId;
    if (mataKuliahName.isNotEmpty) {
      final rows = await db.query('mata_kuliah', where: 'nama = ?', whereArgs: [mataKuliahName]);
      if (rows.isNotEmpty) mkId = rows.first['id'] as int?;
    }

    return await db.insert('jadwal', {
      'mata_kuliah_id': mkId,
      'tanggal': tanggal,
      'waktu': waktu,
    });
  }

  Future<List<dynamic>> getJadwal() async {
    if (kIsWeb) {
      final prefs = await _getPrefs();
      final jsonStr = prefs.getString('jadwal_list') ?? '[]';
      final List<dynamic> jsonList = jsonDecode(jsonStr);
      return List<Map<String, dynamic>>.from(jsonList.map((x) => Map<String, dynamic>.from(x as Map)));
    }
    final db = await database;
    final result = await db.rawQuery('''
      SELECT jadwal.id as id, COALESCE(mata_kuliah.nama, '') as mataKuliah, jadwal.tanggal as tanggal, jadwal.waktu as waktu
      FROM jadwal
      LEFT JOIN mata_kuliah ON jadwal.mata_kuliah_id = mata_kuliah.id
    ''');
    return result.map((row) => row).toList();
  }

  Future<void> deleteJadwal(int id) async {
    if (kIsWeb) {
      final prefs = await _getPrefs();
      final jsonStr = prefs.getString('jadwal_list') ?? '[]';
      final List<dynamic> jsonList = jsonDecode(jsonStr);
      final list = List<Map<String, dynamic>>.from(jsonList.map((x) => Map<String, dynamic>.from(x as Map)));
      list.removeWhere((item) => item['id'] == id);
      await prefs.setString('jadwal_list', jsonEncode(list));
      return;
    }
    final db = await database;
    await db.delete('jadwal', where: 'id = ?', whereArgs: [id]);
  }

  // =========================
  // TUGAS
  // =========================
  Future<int> insertTugas(dynamic tugas) async {
    if (kIsWeb) {
      final prefs = await _getPrefs();
      final jsonStr = prefs.getString('tugas_list') ?? '[]';
      final List<dynamic> jsonList = jsonDecode(jsonStr);
      final list = List<Map<String, dynamic>>.from(jsonList.map((x) => Map<String, dynamic>.from(x as Map)));
      
      Map<String, dynamic> tugasData = {};
      if (tugas is Map<String, dynamic>) {
        tugasData = Map.from(tugas);
      } else {
        tugasData = {
          'deskripsi': tugas.deskripsi ?? '',
          'mataKuliah': tugas.mataKuliah ?? '',
          'tanggal': tugas.tanggal?.toIso8601String() ?? '',
          'waktu': tugas.waktu != null ? '${tugas.waktu.hour}:${tugas.waktu.minute}' : '',
          'selesai': tugas.selesai ? 1 : 0,
        };
      }
      
      int maxId = list.isNotEmpty ? (list.map((m) => (m['id'] as int?) ?? 0).reduce((a, b) => a > b ? a : b)) : 0;
      tugasData['id'] = maxId + 1;
      list.add(tugasData);
      
      await prefs.setString('tugas_list', jsonEncode(list));
      return tugasData['id'] as int;
    }
    
    final db = await database;
    String deskripsi = '';
    String? mataKuliahName;
    String? tanggal;
    String? waktu;
    int selesai = 0;
    
    if (tugas is Map<String, dynamic>) {
      deskripsi = tugas['deskripsi'] ?? '';
      mataKuliahName = tugas['mataKuliah'];
      tanggal = tugas['tanggal'];
      waktu = tugas['waktu'];
      selesai = (tugas['selesai'] == true || tugas['selesai'] == 1) ? 1 : 0;
    } else {
      deskripsi = tugas.deskripsi;
      mataKuliahName = tugas.mataKuliah;
      tanggal = tugas.tanggal?.toIso8601String();
      if (tugas.waktu != null) waktu = '${tugas.waktu.hour}:${tugas.waktu.minute}';
      selesai = tugas.selesai ? 1 : 0;
    }

    int? mkId;
    if (mataKuliahName != null && mataKuliahName.isNotEmpty) {
      final rows = await db.query('mata_kuliah', where: 'nama = ?', whereArgs: [mataKuliahName]);
      if (rows.isNotEmpty) mkId = rows.first['id'] as int?;
    }

    return await db.insert('tugas', {
      'deskripsi': deskripsi,
      'mata_kuliah_id': mkId,
      'tanggal': tanggal,
      'waktu': waktu,
      'selesai': selesai,
    });
  }

  Future<List<dynamic>> getTugas() async {
    if (kIsWeb) {
      final prefs = await _getPrefs();
      final jsonStr = prefs.getString('tugas_list') ?? '[]';
      final List<dynamic> jsonList = jsonDecode(jsonStr);
      return List<Map<String, dynamic>>.from(jsonList.map((x) => Map<String, dynamic>.from(x as Map)));
    }
    final db = await database;
    final result = await db.rawQuery('''
      SELECT tugas.id as id, tugas.deskripsi as deskripsi, COALESCE(mata_kuliah.nama, '') as mataKuliah,
             tugas.tanggal as tanggal, tugas.waktu as waktu, tugas.selesai as selesai
      FROM tugas
      LEFT JOIN mata_kuliah ON tugas.mata_kuliah_id = mata_kuliah.id
    ''');
    return result.map((row) => row).toList();
  }

  Future<void> deleteTugas(int id) async {
    if (kIsWeb) {
      final prefs = await _getPrefs();
      final jsonStr = prefs.getString('tugas_list') ?? '[]';
      final List<dynamic> jsonList = jsonDecode(jsonStr);
      final list = List<Map<String, dynamic>>.from(jsonList.map((x) => Map<String, dynamic>.from(x as Map)));
      list.removeWhere((item) => item['id'] == id);
      await prefs.setString('tugas_list', jsonEncode(list));
      return;
    }
    final db = await database;
    await db.delete('tugas', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> updateTugasSelesai(int id, int selesai) async {
    if (kIsWeb) {
      final prefs = await _getPrefs();
      final jsonStr = prefs.getString('tugas_list') ?? '[]';
      final List<dynamic> jsonList = jsonDecode(jsonStr);
      final list = List<Map<String, dynamic>>.from(jsonList.map((x) => Map<String, dynamic>.from(x as Map)));
      for (var item in list) {
        if (item['id'] == id) {
          item['selesai'] = selesai;
          break;
        }
      }
      await prefs.setString('tugas_list', jsonEncode(list));
      return;
    }
    final db = await database;
    await db.update('tugas', {'selesai': selesai}, where: 'id = ?', whereArgs: [id]);
  }

  // =========================
  // PROFIL
  // =========================
  Future<int> insertProfil(Map<String, dynamic> profil) async {
    if (kIsWeb) {
      final prefs = await _getPrefs();
      profil['id'] = 1;
      await prefs.setString('profil', jsonEncode(profil));
      return 1;
    }
    final db = await database;
    return await db.insert('profil', profil);
  }

  Future<void> updateProfil(Map<String, dynamic> profil) async {
    if (kIsWeb) {
      final prefs = await _getPrefs();
      await prefs.setString('profil', jsonEncode(profil));
      return;
    }
    final db = await database;
    if (profil['id'] != null) {
      await db.update('profil', profil, where: 'id = ?', whereArgs: [profil['id']]);
    }
  }

  Future<Map<String, dynamic>?> getProfil() async {
    if (kIsWeb) {
      final prefs = await _getPrefs();
      final jsonStr = prefs.getString('profil');
      if (jsonStr != null) {
        return Map<String, dynamic>.from(jsonDecode(jsonStr) as Map);
      }
      return null;
    }
    final db = await database;
    final rows = await db.query('profil', limit: 1);
    if (rows.isNotEmpty) return rows.first;
    return null;
  }

  // =========================
  // DEBUG / TEST
  // =========================
  Future<void> testMK() async {
    final data = await getMataKuliah();
    print('JUMLAH MK: ${data.length}');
    print(data);
  }
}
